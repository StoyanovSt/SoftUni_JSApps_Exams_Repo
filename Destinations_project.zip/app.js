const auth = firebase.auth();
const DB = firebase.firestore();

const app = Sammy('#container', function (context) {
    this.use('Handlebars', 'hbs');

    this.get('/', function (context) {
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).userEmail;
        }

        this.userEmail = userEmail;

        DB.collection('destinations')
            .get()
            .then(response => {
                this.destinations = response.docs.map(x => {
                    return {
                        id: x.id,
                        destination: x.data().destination,
                        city: x.data().city,
                        duration: x.data().durationInDays,
                        departureDate: x.data().departureDate,
                        imgUrl: x.data().imgUrl,
                    }
                });

                this.loadPartials({
                    'header': './templates/header-template.hbs',
                    'footer': './templates/footer-template.hbs',
                })
                    .then(function (context) {
                        this.partial('./templates/home-template.hbs');
                    });

            })
            .catch(error => {
                console.log(error.message);
            });

    })

    this.get('#/register', function (context) {
        this.loadPartials({
            'header': './templates/header-template.hbs',
            'footer': './templates/footer-template.hbs',
        })
            .then(function (context) {
                this.partial('./templates/register-template.hbs');
            });
    })

    this.post('#/register', function (context) {
        const { email, password, rePassword } = context.params;

        if (email == '' || !(email.includes('@')) || password == '' || rePassword == '' || password !== rePassword) {
            this.redirect('#/register');
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
            .then(response => {
                const userEmail = response.user.email;
                const userId = response.user.uid;

                localStorage.setItem('user', JSON.stringify({ userEmail, userId }));
                this.redirect('#/register');
                this.redirect('/');
            })
            .catch(error => {
                console.log(error.message);
            });
    })

    this.get('#/login', function (context) {
        this.loadPartials({
            'header': './templates/header-template.hbs',
            'footer': './templates/footer-template.hbs',
        })
            .then(function (context) {
                this.partial('./templates/login-template.hbs');
            });
    })

    this.post('#/login', function (context) {
        const { email, password } = context.params;

        if (email == '' || !(email.includes('@')) || password == '') {
            this.redirect('#/login');
            return;
        }

        auth.signInWithEmailAndPassword(email, password)
            .then(response => {
                const userEmail = response.user.email;
                const userId = response.user.uid;

                localStorage.setItem('user', JSON.stringify({ userEmail, userId }));
                this.redirect('#/login');
                this.redirect('/');
            })
            .catch(error => {
                this.redirect('#/login');
                console.error(error);
            });
    })

    this.get('#/logout', function (context) {
        auth.signOut()
            .then(response => {
                localStorage.removeItem('user');
                this.redirect('#/login');
            })
            .catch(error => {
                console.log(error.message);
            });
    })

    this.get('#/create', function (context) {
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).userEmail;
        }

        this.userEmail = userEmail;

        this.loadPartials({
            'header': './templates/header-template.hbs',
            'footer': './templates/footer-template.hbs',
        })
            .then(function (context) {
                this.partial('./templates/create-template.hbs');
            });
    })

    this.post('#/create', function (context) {
        const { destination, city, duration, departureDate, imgUrl } = context.params;

        if (destination == '' || city == '' || duration == '' || departureDate == '' || imgUrl == '') {
            this.redirect('#/create');
            return;
        }

        const durationInDays = Number(duration);
        const creatorId = JSON.parse(localStorage.getItem('user')).userId;

        const currentDestination = {
            destination,
            city,
            durationInDays,
            departureDate,
            imgUrl,
            creatorId
        };

        DB
            .collection('destinations')
            .add(currentDestination)
            .then(response => {
                this.redirect('/');
            })
            .catch(error => {
                console.log(error.message);
            });
    })

    this.get('#/destinations', function (context) {
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).userEmail;
        }

        this.userEmail = userEmail;

        DB.collection('destinations')
            .get()
            .then(response => {
                const allDestinations = response.docs.map(x => {
                    return {
                        id: x.id,
                        destination: x.data().destination,
                        city: x.data().city,
                        duration: x.data().durationInDays,
                        departureDate: x.data().departureDate,
                        imgUrl: x.data().imgUrl,
                        creatorId: x.data().creatorId
                    }
                });

                this.userDestinations = allDestinations.filter(x => x.creatorId === JSON.parse(localStorage.getItem('user')).userId);

                this.loadPartials({
                    'header': './templates/header-template.hbs',
                    'footer': './templates/footer-template.hbs',
                })
                    .then(function (context) {
                        this.partial('./templates/destinations-template.hbs');
                    });

            })
            .catch(error => {
                console.log(error.message);
            });
    })

    this.get('#/details/:id', function (context) {
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).userEmail;
        }

        this.userEmail = userEmail;

        const { id } = context.params;

        DB
            .collection('destinations')
            .doc(id)
            .get()
            .then(response => {
                const currentDestination = response.data();
                const amITheCreator = currentDestination.creatorId === JSON.parse(localStorage.getItem('user')).userId;

                this.destination = Object.assign(currentDestination, { amITheCreator, id });

                this.loadPartials({
                    'header': './templates/header-template.hbs',
                    'footer': './templates/footer-template.hbs',
                })
                    .then(function (context) {
                        this.partial('./templates/details-template.hbs');
                    });
            })
            .catch(error => {
                console.log(error.message);
            });
    })

    this.get('#/edit/:id', function (context) {
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).userEmail;
        }

        this.userEmail = userEmail;

        const { id } = context.params;

        DB
            .collection('destinations')
            .doc(id)
            .get()
            .then(response => {
                this.currentDestinationToEdit = { ...response.data(), id };

                this.loadPartials({
                    'header': './templates/header-template.hbs',
                    'footer': './templates/footer-template.hbs',
                })
                    .then(function (context) {
                        this.partial('./templates/edit-template.hbs');
                    });

            })
            .catch(error => {
                console.log(error.message);
            });
    })

    this.post('#/edit/:id', function (context) {
        const { destination, city, duration, departureDate, imgUrl, id } = context.params;

        if (destination == '' || city == '' || duration == '' || departureDate == '' || imgUrl == '') {
            this.redirect('#/edit/:id');
            return;
        }

        const durationInDays = Number(duration);

        DB
            .collection('destinations')
            .doc(id)
            .get()
            .then(response => {
                const currentDestinationData = response.data();

                return DB
                    .collection('destinations')
                    .doc(id)
                    .set({
                        ...currentDestinationData,
                        destination,
                        city,
                        durationInDays,
                        departureDate,
                        imgUrl
                    })
            })
            .then(response => {
                this.redirect(`#/details/${id}`);
            })
            .catch(error => {
                console.log(error.message);
            });
    })

    this.get('#/delete/:id', function (context) {
        const { id } = context.params;

        DB
            .collection('destinations')
            .doc(id)
            .delete()
            .then(response => {

                this.redirect('#/destinations');
            })
            .catch(error => {
                console.log(error.message);
            });
    })
});

(() => {
    app.run();
})();