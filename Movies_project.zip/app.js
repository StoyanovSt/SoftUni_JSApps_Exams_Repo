const apiKey = 'AIzaSyBbGlIQs6aetJzc9coA5oQ9kQ4c_LNEBck';
const auth = firebase.auth();
const baseUrl = 'https://movies-project-438d7-default-rtdb.firebaseio.com/Movies/';
const DBUrl = baseUrl + '.json';

const elements = {
    'successNotification': () => document.querySelector('#successNotification'),
    'errorNotification': () => document.querySelector('#errorNotification'),
};

const app = Sammy('#container', function (context) {
    this.use('Handlebars', 'hbs');

    this.get('/', function (context) {        
        
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).email;
        }

        this.userEmail = userEmail;

        fetch(`${DBUrl}`)
            .then(response => response.json())
            .then(data => {
                if (data) {
                    this.movies = Object.keys(data).map(key => {
                        return {
                            id: key,
                            title: data[key].title,
                            description: data[key].description,
                            imageUrl: data[key].imageUrl,
                            creator: data[key].creator,
                        }
                    });
                }

                this.loadPartials({
                    'header': './templates/header-temp.hbs',
                    'footer': './templates/footer-temp.hbs',
                })
                    .then(function (context) {
                        this.partial('./templates/home-temp.hbs');
                    });
                                        
            })
            .catch(err => console.error(err));    

    });

    this.get('#/register', function (context) {
        this.loadPartials({
            'header': './templates/header-temp.hbs',
            'footer': './templates/footer-temp.hbs',
        })
            .then(function (context) {
                this.partial('./templates/register-temp.hbs');
            });
    });

    this.post('#/register', function (context) {
        const { email, password, repeatPassword } = context.params;

        if (email !== '' && password.length >= 6 && password === repeatPassword) {

            fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${apiKey}`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    email,
                    password,
                })
            })
                .then(response => response.json())
                .then(data => {
                    localStorage.setItem('user', JSON.stringify(data));

                    elements.successNotification().textContent = 'Successful register!';
                    elements.successNotification().style.display = 'block';

                    setTimeout(() => {
                        elements.errorNotification().style.display = 'none';
                        this.redirect('#/login');
                    }, 3000);

                })
                .catch(err => console.error(err));

        } else {
            elements.errorNotification().textContent = 'Invalid email or password! Please try again!';
            elements.errorNotification().style.display = 'block';

            setTimeout(() => {
                elements.errorNotification().style.display = 'none';
                context.redirect('#/register');
            }, 3000);

        }

    });

    this.get('#/login', function (context) {
        this.loadPartials({
            'header': './templates/header-temp.hbs',
            'footer': './templates/footer-temp.hbs',
        })
            .then(function (context) {
                this.partial('./templates/login-temp.hbs');
            });
    });

    this.post('#/login', function (context) {
        const { email, password } = context.params;

        if (email !== '' && password !== '') {

            fetch(`https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${apiKey}`, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    email,
                    password,
                })
            })
                .then(response => response.json())
                .then(data => {
                    localStorage.setItem('user', JSON.stringify(data));

                    elements.successNotification().textContent = 'Successful login!';
                    elements.successNotification().style.display = 'block';

                    setTimeout(() => {
                        elements.errorNotification().style.display = 'none';
                        this.redirect('/');
                    }, 3000);

                })
                .catch(err => console.error(err));

        } else {
            elements.errorNotification().textContent = 'Invalid email or password! Please try again!';
            elements.errorNotification().style.display = 'block';

            setTimeout(() => {
                elements.errorNotification().style.display = 'none';
                context.redirect('#/login');
            }, 3000);
        }

    });

    this.get('#/logout', function (context) {
        auth.signOut()
            .then(response => {
                localStorage.removeItem('user');

                elements.successNotification().textContent = 'Successful logout!';
                elements.successNotification().style.display = 'block';

                setTimeout(() => {
                    elements.errorNotification().style.display = 'none';
                    this.redirect('#/login');
                }, 3000);

            })
            .catch(err => {
                console.error(err);
            });
    });

    this.get('#/addMovie', function (context) {
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).email;
        }

        this.userEmail = userEmail;

        this.loadPartials({
            'header': './templates/header-temp.hbs',
            'footer': './templates/footer-temp.hbs',
        })
            .then(function (context) {
                this.partial('./templates/add-movie-temp.hbs');
            });
    });

    this.post('#/addMovie', function (context) {
        const { title, description, imageUrl } = context.params;

        if (title !== '' && description !== '' && imageUrl !== '') {
            const creator = JSON.parse(localStorage.getItem('user')).email;

            const currentMovie = {
                title,
                description,
                imageUrl,
                creator,
            }

            fetch(DBUrl, {
                method: 'POST',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify(currentMovie)
            })
                .then(response => response.json())
                .then(data => {
                    elements.successNotification().textContent = 'Created successfully!';
                    elements.successNotification().style.display = 'block';

                    setTimeout(() => {
                        elements.successNotification().style.display = 'none';
                        context.redirect('/');
                    }, 3000);

                })
                .catch(err => console.log(err));

        } else {
            elements.errorNotification().textContent = 'Invalid inputs!';
            elements.errorNotification().style.display = 'block';

            setTimeout(() => {
                elements.successNotification().style.display = 'none';
                context.redirect('#/addMovie');
            }, 3000);
        }
    });

    this.get('#/details/:id', function (context) {
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).email;
        }

        this.userEmail = userEmail;

        const { id } = context.params;

        fetch(`${baseUrl}${id}/.json`)
            .then(response => response.json())
            .then(currentMovieData => {
                const amITheCreator = currentMovieData.creator === JSON.parse(localStorage.getItem('user')).email;

                this.currentMovie = Object.assign(currentMovieData, { amITheCreator, id});

                this.loadPartials({
                    'header': './templates/header-temp.hbs',
                    'footer': './templates/footer-temp.hbs',
                })
                    .then(function (context) {
                        this.partial('./templates/movie-details-temp.hbs');
                    });
            })
            .catch(err => console.error(err));




    });

    this.get('#/deleteMovie/:id', function (context) {
        const { id } = context.params;

        fetch(`${baseUrl}${id}/.json`, {
            method: 'DELETE'
        })
            .then(response => response.json())
            .then(data => {
                elements.successNotification().textContent = 'Deleted successfully!';
                elements.successNotification().style.display = 'block';

                setTimeout(() => {
                    elements.successNotification().style.display = 'none';
                    context.redirect('/');
                }, 3000);
            })
            .catch(err => console.error(err));
    });

    this.get('#/editMovie/:id', function (context) {
        this.loggedIn = localStorage.getItem('user') ? true : false;

        let userEmail = '';

        if (this.loggedIn) {
            userEmail = JSON.parse(localStorage.getItem('user')).email;
        }

        this.userEmail = userEmail;

        const { id } = context.params;

        fetch(`${baseUrl}${id}/.json`)
            .then(response => response.json())
            .then(currentMovieData => {
                this.currentMovieData = { ...currentMovieData, id };

                this.loadPartials({
                    'header': './templates/header-temp.hbs',
                    'footer': './templates/footer-temp.hbs',
                })
                    .then(function (context) {
                        this.partial('./templates/edit-movie-temp.hbs');
                    });
            })
            .catch(err => console.error());


    });

    this.post('#/editMovie/:id', function (context) {
        const { title, description, imageUrl, id } = context.params;

        if (title !== '' && description !== '' && imageUrl !== '') {
            const currentMovieEdition = {
                title,
                description,
                imageUrl,
            }

            fetch(`${baseUrl}${id}/.json`, {
                method: 'PATCH',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify(currentMovieEdition)
            })
                .then(response => response.json())
                .then(edittedMovie => {
                    elements.successNotification().textContent = 'Eddited successfully!';
                    elements.successNotification().style.display = 'block';

                    setTimeout(() => {
                        elements.successNotification().style.display = 'none';
                        context.redirect(`#/details/${id}`);
                    }, 3000);
                })
                .catch(err => console.error(err));

        } else {
            elements.errorNotification().textContent = 'Invalid inputs!';
            elements.errorNotification().style.display = 'block';

            setTimeout(() => {
                elements.successNotification().style.display = 'none';
                context.redirect(`#/editMovie/${id}`);
            }, 3000);
        }

    });

});

(() => {
    app.run();
})();